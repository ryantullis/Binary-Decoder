javac Decoder.java
